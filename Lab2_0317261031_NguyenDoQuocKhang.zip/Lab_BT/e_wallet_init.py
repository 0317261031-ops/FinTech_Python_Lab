# Nhập thông tin khách hàng từ bàn phím
ho_ten = input("Nhập họ và tên khách hàng: ")
so_dien_thoai = input("Nhập số điện thoại: ")
cccd = input("Nhập số Căn cước công dân (CCCD): ")
so_tien_nap = float(input("Nhập số tiền nạp ban đầu (VND): "))

# Xử lý tính toán
phi_mo_vi = 50000
so_du_kha_dung = so_tien_nap - phi_mo_vi
bon_so_cuoi_cccd = cccd[-4:]  # Lấy 4 ký tự cuối chuỗi CCCD

# In biên lai khởi tạo ví
print("\n" + "=" * 40)
print("BIÊN LAI KHỞI TẠO VÍ ĐIỆN TỬ")
print("=" * 40)
print(f"Họ và tên: {ho_ten.upper()}")
print(f"Số điện thoại: {so_dien_thoai}")
print(f"4 số cuối CCCD: {bon_so_cuoi_cccd}")
print(f"Số tiền nạp: {so_tien_nap:,.0f} VND")
print(f"Phí mở ví: {phi_mo_vi:,.0f} VND")
print(f"Số dư khả dụng thực tế: {so_du_kha_dung:,.0f} VND")
print("=" * 40)
