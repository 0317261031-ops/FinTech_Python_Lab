# Bài 2: Script Hello FinTech đầu tiên
# Mô tả: In thông báo khởi tạo hệ thống tài chính số
# Hiển thị tiêu đề hệ thống
print("==================================================")
print(" CHÀO MỪNG ĐẾN VỚI HỆ THỐNG FINTECH & DIGITAL ")
print("==================================================")
# In thông báo trạng thái
print("Khởi tạo môi trường lập trình Python thành công.")
print("Sẵn sàng xử lý các giao dịch tài chính tự động!")