X = float(input("Nhập tổng hóa đơn (X): "))
Y = float(input("Nhập % tip (Y): "))
N = int(input("Nhập số người (N): "))

tong_tien = X * (1 + Y / 100)
tien_moi_nguoi = tong_tien / N

# Làm tròn đến số nguyên (0 chữ số thập phân)
print(f"Mỗi người phải trả: {round(tien_moi_nguoi)} đồng")