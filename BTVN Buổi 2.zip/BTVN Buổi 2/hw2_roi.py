von_ban_dau = float(input("Nhập tổng vốn ban đầu (Initial Investment): "))
gia_tri_ban = float(input("Nhập tổng giá trị bán ra (Final Value): "))

loi_nhuan_rong = gia_tri_ban - von_ban_dau
roi = (loi_nhuan_rong / von_ban_dau) * 100

print(f"Lợi nhuận ròng (Net Profit): {loi_nhuan_rong}")
print(f"Tỷ lệ ROI: {roi:.2f}%")